/* eslint-disable no-undef */

import React, { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import axios from "axios";
import { getHeaders } from "../../utility/getHeader";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { ComboBox } from "../../components/Buttons/ComboBox";
import CardComponent from "../../components/cards/CardComponent";

import Header from "../../components/Header";
import Layout from "../../layout/Layout";
import { format } from "date-fns";

import { TextfieldwithLabel } from "../../components/Buttons/Textfield";
import { SubmitButton } from "../../components/Buttons/Textfield";
import DataTable from "../../components/data-tables/dataTable";
import SimpleDataTable from "../../components/data-tables/SimpledataTable";
import fetchData from "../../functions/fetchData";

export default function SubCategories() {
  let currentDate = format(new Date(), "yyyy-MM-dd");
  //  const headers = { Authorization: authheader().access_token };
  const [data, setData] = useState([]);
  const [errors, setErrors] = useState({});
  const [formdata, setFormData] = useState({
    catid: "", // Category ID
    subcatname: "", // Subcategory name
  });
  const columns = [
    { label: "ID", field: "id" },
    { label: "Category", field: "cat_id" },
    { label: "Sub Category", field: "subcat" },
    { label: "Actions", field: "actions" }
  ];
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    // alert(e.target);
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!formdata.catid) {
      toast.error("Please select a category first");
      return;
    }
    
    if (!formdata.subcatname || formdata.subcatname.trim() === "") {
      toast.error("Please enter a subcategory name");
      return;
    }

    try {
      console.log("📤 Submitting subcategory:", {
        cat_id: formdata.catid,
        subcat: formdata.subcatname.trim()
      });

      await axios.post(
        "/insertdata/subcategory",
        {
          cat_id: formdata.catid,
          subcat: formdata.subcatname.trim(),
        },
        getHeaders()
      );
     
      // Fetch the updated data after successful submission
      await fetchData("subcategory", setData, "id", {});

      toast.success("Sub Category added successfully!");
      
      // Only clear the subcategory name, keep the selected category
      setFormData(prevData => ({
        ...prevData,
        subcatname: "" // Only clear the subcategory name
        // Keep catid so user can add multiple subcategories under same category
      }));
    } catch (err) {
      toast.error("Error in adding subcategory");
      console.error("❌ Submission error:", err);
      if (err.response) {
        console.error("❌ Error response:", err.response.data);
      }
    }
    
    setErrors({});
  };

 

  useEffect(() => {
    const fetchAndSetData = async () => {
      try {
        await fetchData("subcategory", setData, "id", {});
        console.log("Fetched data:", data); // Add this line for debugging
      } catch (error) {
        console.error("Error in useEffect:", error);
      }
    };

    fetchAndSetData();
  }, []);
  return (
    <>
      <Layout>
        <Header title="Add New Sub Category" />
        <ToastContainer />
        <div className="row">
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <CardComponent
              title="Add Sub Category for the product List"
              headerColor="darkorange"
              pull="left"
              bodyClass="panel-body"
            >
                 <form onSubmit={handleSubmit}>
             
                 
                    <div class="panel panel-default card-view">
                    <div class="row">
                    <div class="col-md-12">   
                        <ComboBox
                        id="property_type"
                        onChange={(e) => handleInputChange(e)}
                        name="catid"
                        value={formdata.catid}
                        tablename="categories"
                        groupby="name"
                        lable="Select Category"
                        displayField="id"
                        displayValue="name"
                        />
                        {formdata.catid && (
                          <button 
                            type="button" 
                            className="btn btn-sm btn-warning mt-2"
                            onClick={() => setFormData(prev => ({ ...prev, catid: "", subcatname: "" }))}
                          >
                            Clear Category Selection
                          </button>
                        )}
                        </div>
                    <div class="col-md-12">

                      <TextfieldwithLabel
                        id="subcatname"
                        onChange={(e) => handleInputChange(e)}
                        value={formdata.subcatname}
                        type="text"
                        name="subcatname"
                        lable="Sub Category Name"
                      />
                    </div>
                    <div class="col-md-12">  
                    <div className="form-group">
                      <label className="control-label mb-12"></label>
                      <SubmitButton
                        type="submit"
                        name="Save"
                        cls="btn btn-darkblue btn-anim"
                      />
                    </div>
                    </div>
                  
                </div>
                </div>
                </form>
              
            </CardComponent>
          </div>
          {/* <ExportDataTable
                                tableId="tableid"
                                tableData={data} /> */}
          <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12" id="tableid">
            {data.length === 0 ? (
              <p>No data available</p>
            ) : (
              //  <DataTable columns={columns} data={data} onFilter={handleFilter} />
              <DataTable columns={columns} data={data} tablename="subcategory" />
            )}

            {/* <CardComponent 
                            title=""
                            headerContent=
                            {
                            <ExportDataTable
                                tableId="datatable1"
                                tableData={data} // Pass complete dataset to export function
                            />
                            }
                            headerColor="lightblue"
                            pull="right"
                            bodyClass="panel-body">

                            {data.length === 0 ? (
                                <p>No data available</p>
                            ) : (
                                 <DataTable columns={columns} data={data} onFilter={handleFilter} />
                                //<SimpleDataTable columns={columns} data={data}/>
                            )}

                        </CardComponent> */}
          </div>
        </div>
      </Layout>
    </>
  );
}
