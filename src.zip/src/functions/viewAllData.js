import axios from "axios";
import { getHeaders } from "../utility/getHeader";


const fetchdatanotequal = async (tblname, setData, orderby, where) => {
    // Build the URL dynamically based on the provided parameters
    let url = `/fetchdatanotequal`;
    if (tblname) {
        url += `/${tblname}`;
    }
    if (orderby) {
        url += `/${orderby}`;
    }
    if (where) {
        const whereParams = new URLSearchParams(where).toString();
        url += `/${whereParams}`;
        
       
    }
    //console.log(url);
    // if(tblname==="final_bill")
    // {
    //     console.log("Fetch url data");
    //     console.log(url);

    // }
    
    const headers = getHeaders();
    const response = await axios.get(url, headers);

    // If a setData function is provided, update the state with the fetched data
    if (setData && typeof setData === 'function') {
        setData(response.data.data)
      //  console.log(response.data.data);
    //     if(tblname==="final_bill")
    //         {
    //             console.log("getch final bill data:");
    //    console.log(response.data.data);
    //         }
    }
    return response.data.data;
}


export default   fetchdatanotequal;

